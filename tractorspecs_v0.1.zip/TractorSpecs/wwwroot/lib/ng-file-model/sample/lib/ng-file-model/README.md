# ng-file-model
----
[![Bower version](https://badge.fury.io/bo/ng-file-model.svg)](http://badge.fury.io/bo/ng-file-model)
----
Angular File Model is a directive for angularjs to help you make a model for input file and you can send it to sever for next step.

`> bower install ng-file-model --save`

----
Created By Mistral Works | 2015