﻿namespace TractorSpecs.Core.Interfaces
{
    public interface IEnvironmentConfigSettingsGetter
    {
        string GetValueByKey(string key);
    }
}