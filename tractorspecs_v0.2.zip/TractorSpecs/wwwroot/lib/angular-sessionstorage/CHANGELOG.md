# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## 1.1.1
### Fixed
- Version number in bower.json

## 1.1.0
### Fixed
- Use temporary memory-base storage if session storage is not available or accessible

## 1.0.0
### Added
- Initial implementation
