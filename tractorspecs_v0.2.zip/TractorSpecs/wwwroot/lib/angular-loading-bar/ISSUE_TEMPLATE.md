#### Description of bug:


#### Expected result:


#### Actual result:


#### Browsers affected:


#### URL of reduced test case:

