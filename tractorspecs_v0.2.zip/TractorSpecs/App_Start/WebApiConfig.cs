﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json.Serialization;
using System.Web.OData.Builder;
using System.Web.OData.Extensions;
using System.Web.Http.Dispatcher;
using TractorSpecs.Core.Models;
using TractorSpecs.Core.Objects;

namespace TractorSpecs
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            // Configure Web API to use only bearer token authentication.
            config.SuppressDefaultHostAuthentication();
            config.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));

            // Use camel case for JSON data.
            config.Formatters.JsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // New code:
            ODataModelBuilder builder = new ODataConventionModelBuilder();

            // http://odata.github.io/WebApi/#13-01-modelbound-attribute
            // http://stackoverflow.com/questions/39515218/odata-error-the-query-specified-in-the-uri-is-not-valid-the-property-cannot-be
            config.Count().Filter().OrderBy().Expand().Select().MaxTop(null); //new line

            builder.EntitySet<model>("models");

            builder.EntityType<specification>().Collection
                .Function("GetModelWithEmptySpecificationsByModelId")
                .Returns<IEnumerable<specification>>()
                .Namespace = "specificationsService";

            //builder.StructuralTypes.First(x => x.ClrType.FullName.Contains("specification"))
            //    .AddProperty((typeof(specName)).GetProperty("specName"));

            //var function = builder.EntityType<model>().Function("GetModelWithEmptySpecificationsByModelId");
            //function.ReturnsFromEntitySet<model>("models");
            //function.Parameter<int>("modelId");
            //function.Namespace = "modelsService";

            builder.EntitySet<equipmentClass>("equipmentClass");

            builder.EntitySet<make>("makes");

            //builder.StructuralTypes.First(x => x.ClrType.FullName.Contains("make"))
            //    .AddProperty((typeof(make)).GetProperty("modelCountCalculated"));

            // Example: http://localhost:17753/odata/makes/makesService.GetMakesWithModelsCount
            builder.EntityType<make>().Collection
                .Function("GetMakesWithModelsCount")
                .Returns<IEnumerable<make>>()
                .Namespace = "makesService";

            builder.EntitySet<specification>("specifications");

            builder.EntitySet<specClass>("specClasses");

            builder.EntitySet<equipmentClass>("equipmentClasses");

            builder.EntitySet<specName>("specNames");

            // http://stackoverflow.com/questions/36344979/odata-include-custom-properties-added-to-entity-framework-models-via-partial-c
            // http://stackoverflow.com/questions/27277306/odata-read-only-property
            //builder.StructuralTypes.First(x => x.ClrType.FullName.Contains("model"))
            //    .AddProperty((typeof(model)).GetProperty("blogBodySummaryHtml"));

            //builder.StructuralTypes.First(x => x.ClrType.FullName.Contains("blogEntry"))
            //    .AddProperty((typeof(blogEntry)).GetProperty("monthAbbreviation"));

            //builder.StructuralTypes.First(x => x.ClrType.FullName.Contains("blogEntry"))
            //    .AddProperty((typeof(blogEntry)).GetProperty("day"));

            //builder.StructuralTypes.First(x => x.ClrType.FullName.Contains("blogEntry"))
            //    .AddProperty((typeof(blogEntry)).GetProperty("year"));

            builder.EntitySet<link>("links");

            builder.EntitySet<review>("reviews");

            builder.EntitySet<modelPrice>("modelPrices");

            builder.EntitySet<user>("users");

            builder.EntitySet<modelPicture>("modelPictures");

            builder.EntitySet<specChangeLog>("specChangeLogs");

            builder.StructuralTypes.First(x => x.ClrType.FullName.Contains("modelPicture"))
                .AddProperty((typeof(modelPicture)).GetProperty("base64String"));

            builder.EntityType<user>().Collection
                .Function("GetLoggedInUser")
                .Returns<string>()
                .Namespace = "usersService";

            config.MapODataServiceRoute(
                routeName: "ODataRoute",
                routePrefix: "odata",
                model: builder.GetEdmModel());
        }
    }
}
