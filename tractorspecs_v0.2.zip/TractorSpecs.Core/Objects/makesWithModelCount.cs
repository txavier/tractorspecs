﻿namespace TractorSpecs.Core.Objects
{
    public class makesWithModelCount
    {
        public int makesWithModelCountId { get; set;}
        public long makeId { get; set; }
        public string mfgName { get; set; }
        public int modelsCount { get; set; }
    }
}